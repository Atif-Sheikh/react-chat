
const getMenuItems = (props) => {
  // const { auth: authData, updateLocale, intl } = props
  // const { setAuth } = authData


  // const localeItems = allLocales.map((l) => {
  //   const result = {
  //     value: undefined,
  //     visible: true,
  //     key: l.locale,
  //     primaryText: intl.formatMessage({ id: l.locale }),
  //     onClick: () => {
  //       updateLocale(l.locale)
  //     },
  //   }
  //   return result
  // })

  // const handleSignOut = () => {
  //   setAuth({ isAuthenticated: false })
  // }

  return []
}

export default getMenuItems
